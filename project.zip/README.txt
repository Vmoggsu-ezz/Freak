FPS CLIENT - REPAIRED BUILD PROJECT (Minecraft Java 1.21.11)

WHAT WAS WRONG WITH THE UPLOADED FILE
The uploaded file was a source bundle, not an installable mod JAR:
- It contained .java source files under three version folders.
- It had no compiled .class files.
- Its fabric.mod.json files were buried inside each version's source tree, not at the JAR root.
- Its own README explicitly said it had not been compiled against Minecraft.
Minecraft therefore cannot load that uploaded archive as a Fabric mod.

WHAT THIS PROJECT TARGETS
- Minecraft Java Edition 1.21.11 only
- Fabric Loader 0.18.1 or newer
- Fabric API 0.141.6+1.21.11
- Java 21
- Fabric Loom 1.18.4 / Gradle 9.2 or newer

CHANGES IN THIS SOURCE PROJECT
- Correct standard Fabric Gradle project layout and mod metadata.
- Right Shift opens the FPS Client modules menu; pressing Right Shift again closes it.
- Menu buttons still toggle each module and save its state.
- FPS Booster now saves/restores more settings and applies a stronger preset:
  Fast graphics, minimal particles, clouds off, entity shadows off, biome blend 0,
  entity distance 0.35, render distance up to 8 chunks, simulation distance up to 5,
  ambient occlusion off, VSync off and FPS cap removed (260 slider value).
- Turning FPS Booster off restores the values that were in use before activation.
- Toggle Sprint releases its forced sprint key when the module is disabled or the menu opens.

IMPORTANT LIMITATIONS
This is a BUILD PROJECT, not a compiled, tested .jar. A real mod JAR must be compiled
against Minecraft/Fabric libraries. This environment has no Gradle installation and
cannot reach Fabric/Minecraft Maven repositories, so I cannot honestly claim the game
binary has been compiled or tested here.

HOW TO BUILD ON A COMPUTER
1. Install Java 21 and Gradle 9.2 or newer.
2. Open this project folder in a terminal.
3. Run build.bat on Windows, or ./build.sh on macOS/Linux (or run: gradle build).
4. After a successful build, use:
   build/libs/fpsclient-fixed-1.21.11-1.0.1.jar
5. Put that compiled JAR in .minecraft/mods alongside Fabric Loader and Fabric API
   for Minecraft 1.21.11. Remove older duplicate FPS Client copies first.

CONTROLS
- Right Shift: open/close the FPS Client menu (also rebindable in Options > Controls).
- B: toggle FPS Booster while in-game.
- C: hold to zoom (when Zoom is enabled).

FPS NOTE
The FPS Booster changes Minecraft's graphics settings to reduce GPU/CPU workload; it
cannot guarantee a fixed FPS gain. Results depend on hardware, shaders, resource packs,
world complexity and other mods. It does not reduce server ping.

BUILD WITHOUT INSTALLING ANYTHING (GitHub)
1. Create a free GitHub account and a new repository.
2. Upload ALL files from this project (including the hidden .github folder).
3. Open the Actions tab, wait for "Build mod" to finish (green check).
4. Open that run, download the artifact "fpsclient-mod-jar", unzip it:
   the .jar inside is the mod. Put it in .minecraft/mods with Fabric API.
