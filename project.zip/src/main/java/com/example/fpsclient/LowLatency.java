package com.example.fpsclient;

import net.minecraft.client.MinecraftClient;

/**
 * Cuts the delay between your click and the picture changing (input lag) by turning
 * vsync off and removing the FPS cap. This does NOT change network ping, but the game
 * feels more responsive, especially if vsync was on.
 */
public final class LowLatency {
    private static boolean active;

    private LowLatency() {}

    public static void apply(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;

        if (on && !active) {
            LatencyOptions.acquire(mc.options);
            active = true;
        } else if (!on && active) {
            LatencyOptions.release(mc.options);
            active = false;
        }
    }
}
