package com.example.fpsclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Direction;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Locale;

/** On-screen panels. Original look: dark translucent boxes with a violet edge. */
public final class Hud {
    private static final int BG = 0x90101018;
    private static final int ACCENT = 0xFF8B5CF6;
    private static final int KEY_DOWN = 0xC08B5CF6;
    private static final int TEXT = 0xFFFFFFFF;

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean lastLeft;
    private static boolean lastRight;

    private Hud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        pollClicks(mc);
        if (mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        int x = 6;
        int y = 6;

        if (Feature.FPS.enabled()) y = panel(ctx, tr, x, y, mc.getCurrentFps() + " FPS");
        if (Feature.CPS.enabled()) y = panel(ctx, tr, x, y, "CPS " + LEFT.size() + " | " + RIGHT.size());
        if (Feature.PING.enabled()) y = panel(ctx, tr, x, y, "Ping " + Stats.ping(mc) + " ms");
        if (Feature.PING_GRAPH.enabled()) y = pingGraph(ctx, tr, x, y, mc);
        if (Feature.SPEED.enabled()) {
            y = panel(ctx, tr, x, y, String.format(Locale.ROOT, "%.1f b/s", Stats.bps));
        }
        if (Feature.CLOCK.enabled()) {
            y = panel(ctx, tr, x, y, LocalTime.now().format(TIME) + " | Day " + (mc.world.getTime() / 24000L));
        }
        if (Feature.MEMORY.enabled()) {
            Runtime rt = Runtime.getRuntime();
            long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
            y = panel(ctx, tr, x, y, "RAM " + used + "/" + (rt.maxMemory() / 1048576L) + " MB");
        }
        if (Feature.COORDS.enabled()) {
            y = panel(ctx, tr, x, y,
                    "XYZ " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
        }
        if (Feature.DIRECTION.enabled()) y = panel(ctx, tr, x, y, direction(mc));
        if (Feature.DEATH_POINT.enabled() && Stats.hasDeath) {
            y = panel(ctx, tr, x, y, "Died at " + Stats.deathX + " " + Stats.deathY + " " + Stats.deathZ);
        }
        if (Feature.ITEMS.enabled()) y = panel(ctx, tr, x, y, itemLine(mc));
        if (FpsBooster.isActive()) y = panel(ctx, tr, x, y, "BOOST ON");
        if (Feature.KEYSTROKES.enabled()) drawKeys(ctx, tr, x, y + 2, mc);

        if (Feature.POTIONS.enabled()) drawPotions(ctx, tr, mc);
        if (Feature.ARMOR.enabled()) drawArmor(ctx, tr, mc);
    }

    // ---------- data helpers ----------


    /** Last 60 seconds of ping as small bars (green = good, red = bad), with avg/max and a spike warning. */
    private static int pingGraph(DrawContext ctx, TextRenderer tr, int x, int y, MinecraftClient mc) {
        if (mc.isInSingleplayer()) return panel(ctx, tr, x, y, "Ping graph: n/a (singleplayer)");

        boolean spike = System.currentTimeMillis() < Stats.spikeUntil;
        String head = (spike ? "PING SPIKE " : "Ping ") + "avg " + Stats.averagePing()
                + " | max " + Stats.maxPing() + " ms";
        int w = Math.max(tr.getWidth(head) + 10, Stats.HISTORY * 2 + 10);
        int h = 40;

        ctx.fill(x, y, x + w, y + h, BG);
        ctx.fill(x, y, x + 2, y + h, spike ? 0xFFFF5555 : ACCENT);
        ctx.drawText(tr, head, x + 6, y + 3, spike ? 0xFFFF8080 : TEXT, false);

        int base = y + h - 3;
        for (int i = 0; i < Stats.pingCount(); i++) {
            int p = Stats.pingAt(i);
            int bar = Math.max(1, Math.min(20, p / 10));
            int color = p < 60 ? 0xFF55FF55 : p < 120 ? 0xFFFFFF55 : 0xFFFF5555;
            int bx = x + 6 + i * 2;
            ctx.fill(bx, base - bar, bx + 1, base, color);
        }
        return y + h + 2;
    }

    private static String direction(MinecraftClient mc) {
        Direction d = mc.player.getHorizontalFacing();
        return switch (d) {
            case NORTH -> "N (-Z)";
            case SOUTH -> "S (+Z)";
            case WEST -> "W (-X)";
            case EAST -> "E (+X)";
            default -> d.name();
        };
    }

    private static String itemLine(MinecraftClient mc) {
        PlayerInventory inv = mc.player.getInventory();
        return "Totems " + count(inv, Items.TOTEM_OF_UNDYING)
                + " | Crystals " + count(inv, Items.END_CRYSTAL)
                + " | Glow " + count(inv, Items.GLOWSTONE)
                + " | Anchors " + count(inv, Items.RESPAWN_ANCHOR);
    }

    private static int count(PlayerInventory inv, Item item) {
        int n = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    private static String formatTicks(int ticks) {
        int s = ticks / 20;
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    private static void pollClicks(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        boolean left = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();

        if (mc.currentScreen == null) {
            if (left && !lastLeft) LEFT.addLast(now);
            if (right && !lastRight) RIGHT.addLast(now);
        }
        lastLeft = left;
        lastRight = right;

        while (!LEFT.isEmpty() && now - LEFT.peekFirst() > 1000) LEFT.removeFirst();
        while (!RIGHT.isEmpty() && now - RIGHT.peekFirst() > 1000) RIGHT.removeFirst();
    }

    // ---------- drawing ----------

    private static int panel(DrawContext ctx, TextRenderer tr, int x, int y, String text) {
        int w = tr.getWidth(text) + 10;
        ctx.fill(x, y, x + w, y + 14, BG);
        ctx.fill(x, y, x + 2, y + 14, ACCENT);
        ctx.drawText(tr, text, x + 6, y + 3, TEXT, false);
        return y + 16;
    }

    private static void drawKeys(DrawContext ctx, TextRenderer tr, int x, int y, MinecraftClient mc) {
        int s = 20;
        int g = 2;
        key(ctx, tr, x + s + g, y, s, s, "W", mc.options.forwardKey.isPressed());
        key(ctx, tr, x, y + s + g, s, s, "A", mc.options.leftKey.isPressed());
        key(ctx, tr, x + s + g, y + s + g, s, s, "S", mc.options.backKey.isPressed());
        key(ctx, tr, x + 2 * (s + g), y + s + g, s, s, "D", mc.options.rightKey.isPressed());

        int half = (3 * s + 2 * g - g) / 2;
        key(ctx, tr, x, y + 2 * (s + g), half, 16, "LMB", lastLeft);
        key(ctx, tr, x + half + g, y + 2 * (s + g), half, 16, "RMB", lastRight);
    }

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String label, boolean down) {
        ctx.fill(x, y, x + w, y + h, down ? KEY_DOWN : BG);
        ctx.drawCenteredTextWithShadow(tr, label, x + w / 2, y + (h - 8) / 2, TEXT);
    }

    /** Active potion effects, top-right (below vanilla's own effect icons). */
    private static void drawPotions(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        int right = mc.getWindow().getScaledWidth() - 6;
        int y = 56;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
            String time = e.isInfinite() ? "inf" : formatTicks(e.getDuration());
            String text = name + "  " + time;
            int w = tr.getWidth(text) + 10;
            int px = right - w;
            boolean low = !e.isInfinite() && e.getDuration() < 200;
            ctx.fill(px, y, px + w, y + 14, BG);
            ctx.fill(px + w - 2, y, px + w, y + 14, ACCENT);
            ctx.drawText(tr, text, px + 4, y + 3, low ? 0xFFFF8080 : TEXT, false);
            y += 16;
        }
    }

    /** Armor + held item with remaining durability, right side of the screen. */
    private static void drawArmor(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        int x = mc.getWindow().getScaledWidth() - 22;
        int y = mc.getWindow().getScaledHeight() / 2 - 44;
        for (EquipmentSlot slot : ARMOR) {
            y = armorRow(ctx, tr, mc.player.getEquippedStack(slot), x, y);
        }
        armorRow(ctx, tr, mc.player.getMainHandStack(), x, y);
    }

    private static int armorRow(DrawContext ctx, TextRenderer tr, ItemStack stack, int x, int y) {
        if (stack.isEmpty()) return y;
        ctx.drawItem(stack, x, y);
        if (stack.isDamageable()) {
            int left = stack.getMaxDamage() - stack.getDamage();
            float frac = (float) left / stack.getMaxDamage();
            int color = frac > 0.5f ? 0xFF55FF55 : frac > 0.25f ? 0xFFFFFF55 : 0xFFFF5555;
            String s = String.valueOf(left);
            ctx.drawText(tr, s, x - 3 - tr.getWidth(s), y + 4, color, true);
        }
        return y + 18;
    }
}
