package com.example.fpsclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Tiny on/off settings file: .minecraft/config/fpsclient.properties */
public final class Config {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("fpsclient.properties");
    private static final Properties PROPS = new Properties();

    private Config() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try (var in = Files.newInputStream(FILE)) {
            PROPS.load(in);
        } catch (IOException ignored) {
        }
    }

    public static void save() {
        try (var out = Files.newOutputStream(FILE)) {
            PROPS.store(out, "FPS Client settings");
        } catch (IOException ignored) {
        }
    }

    public static boolean get(String key, boolean fallback) {
        return Boolean.parseBoolean(PROPS.getProperty(key, String.valueOf(fallback)));
    }

    public static void set(String key, boolean value) {
        PROPS.setProperty(key, String.valueOf(value));
        save();
    }
}
