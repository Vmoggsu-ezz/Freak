package com.example.fpsclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/**
 * One-key performance preset. Saves your current video settings, switches to
 * cheaper ones, and puts everything back when you turn it off (or close the game).
 * Gains depend on your PC and the scene - busy scenes (PvP, lots of entities) gain most.
 */
public final class FpsBooster {
    private static boolean active;

    private static ParticlesMode particles;
    private static CloudRenderMode clouds;
    private static boolean shadows;
    private static int blend;
    private static GraphicsMode graphics;
    private static double entityDistance;
    private static int viewDistance;
    private static int simulationDistance;
    private static boolean ambientOcclusion;

    private FpsBooster() {}

    public static boolean isActive() {
        return active;
    }

    public static void apply(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;
        GameOptions o = mc.options;

        if (on && !active) {
            particles = o.getParticles().getValue();
            clouds = o.getCloudRenderMode().getValue();
            shadows = o.getEntityShadows().getValue();
            blend = o.getBiomeBlendRadius().getValue();
            graphics = o.getGraphicsMode().getValue();
            entityDistance = o.getEntityDistanceScaling().getValue();
            viewDistance = o.getViewDistance().getValue();
            simulationDistance = o.getSimulationDistance().getValue();
            ambientOcclusion = o.getAo().getValue();

            o.getParticles().setValue(ParticlesMode.MINIMAL);
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            o.getEntityShadows().setValue(false);
            o.getBiomeBlendRadius().setValue(0);
            o.getGraphicsMode().setValue(GraphicsMode.FAST);
            o.getEntityDistanceScaling().setValue(0.5);
            o.getViewDistance().setValue(Math.min(viewDistance, 8));
            o.getSimulationDistance().setValue(Math.min(simulationDistance, 5));
            o.getAo().setValue(false);
            LatencyOptions.acquire(o); // vsync off + unlimited FPS
            active = true;
        } else if (!on && active) {
            o.getParticles().setValue(particles);
            o.getCloudRenderMode().setValue(clouds);
            o.getEntityShadows().setValue(shadows);
            o.getBiomeBlendRadius().setValue(blend);
            o.getGraphicsMode().setValue(graphics);
            o.getEntityDistanceScaling().setValue(entityDistance);
            o.getViewDistance().setValue(viewDistance);
            o.getSimulationDistance().setValue(simulationDistance);
            o.getAo().setValue(ambientOcclusion);
            LatencyOptions.release(o);
            active = false;
        }
    }
}
