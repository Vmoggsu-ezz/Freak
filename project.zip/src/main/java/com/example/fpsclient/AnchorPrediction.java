package com.example.fpsclient;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;

/**
 * Hides network delay for respawn anchor explosions: the anchor disappears on your
 * screen immediately instead of after the server's reply. The server still decides
 * what really happens and corrects the client if it disagrees.
 * (If you also use the standalone AnchorOptimizer jar, remove it - this replaces it.)
 */
public final class AnchorPrediction {
    private AnchorPrediction() {}

    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!Feature.ANCHOR_PREDICT.enabled()) return ActionResult.PASS;
            if (!world.isClient()) return ActionResult.PASS;
            if (player.isSpectator() || player.isSneaking()) return ActionResult.PASS;

            BlockPos pos = hitResult.getBlockPos();
            BlockState state = world.getBlockState(pos);
            if (!state.isOf(Blocks.RESPAWN_ANCHOR)) return ActionResult.PASS;

            // In the Nether the anchor sets your spawn instead of exploding.
            if (RespawnAnchorBlock.isNether(world)) return ActionResult.PASS;

            int charges = state.get(RespawnAnchorBlock.CHARGES);
            if (charges <= 0) return ActionResult.PASS;

            boolean holdingGlowstone = player.getStackInHand(hand).isOf(Items.GLOWSTONE);

            // Glowstone charges the anchor (instead of exploding) until it is full.
            if (holdingGlowstone && charges < RespawnAnchorBlock.MAX_CHARGES) return ActionResult.PASS;

            // Main hand defers to an off-hand glowstone, same as vanilla.
            if (hand == Hand.MAIN_HAND && !holdingGlowstone
                    && player.getStackInHand(Hand.OFF_HAND).isOf(Items.GLOWSTONE)) {
                return ActionResult.PASS;
            }

            // Predict the explosion (flag 2 = update listeners/rendering).
            world.setBlockState(pos, Blocks.AIR.getDefaultState(), 2);

            // SUCCESS skips vanilla's client-side item use but the interact packet is still sent.
            return ActionResult.SUCCESS;
        });
    }
}
