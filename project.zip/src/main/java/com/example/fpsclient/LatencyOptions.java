package com.example.fpsclient;

import net.minecraft.client.option.GameOptions;

/**
 * Vsync off + unlimited FPS cap, shared by FPS Booster and Low latency mode.
 * Original values are saved by whichever turns it on first and restored when the
 * last one turns it off, so the two features never fight over these settings.
 */
final class LatencyOptions {
    private static int users;
    private static boolean vsync;
    private static int maxFps;

    private LatencyOptions() {}

    static void acquire(GameOptions o) {
        if (users++ == 0) {
            vsync = o.getEnableVsync().getValue();
            maxFps = o.getMaxFps().getValue();
            o.getEnableVsync().setValue(false);
            o.getMaxFps().setValue(260); // 260 = unlimited
        }
    }

    static void release(GameOptions o) {
        if (users > 0 && --users == 0) {
            o.getEnableVsync().setValue(vsync);
            o.getMaxFps().setValue(maxFps);
        }
    }
}
