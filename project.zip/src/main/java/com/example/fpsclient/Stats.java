package com.example.fpsclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;

/** Values that need to be tracked every tick (speed, last death point). */
public final class Stats {
    public static double bps;
    public static boolean hasDeath;
    public static int deathX;
    public static int deathY;
    public static int deathZ;

    public static final int HISTORY = 60;
    public static long spikeUntil;

    private static final int[] PINGS = new int[HISTORY];
    private static int pingCount;
    private static int pingHead;
    private static int pingTimer;

    private static double lastX;
    private static double lastZ;
    private static boolean haveLast;
    private static boolean wasDead;

    private Stats() {}

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            haveLast = false;
            pingCount = 0;
            return;
        }

        if (++pingTimer >= 20) { // one sample per second
            pingTimer = 0;
            samplePing(mc);
        }

        if (haveLast) {
            double now = Math.hypot(p.getX() - lastX, p.getZ() - lastZ) * 20.0;
            bps = bps * 0.8 + now * 0.2; // smoothed so the number doesn't jitter
        }
        lastX = p.getX();
        lastZ = p.getZ();
        haveLast = true;

        boolean dead = p.isDead();
        if (dead && !wasDead) {
            hasDeath = true;
            deathX = p.getBlockX();
            deathY = p.getBlockY();
            deathZ = p.getBlockZ();
        }
        wasDead = dead;
    }

    /** Latency to the server in ms (0 in singleplayer). */
    public static int ping(MinecraftClient mc) {
        if (mc.player == null) return 0;
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();
        if (handler == null) return 0;
        PlayerListEntry entry = handler.getPlayerListEntry(mc.player.getUuid());
        return entry == null ? 0 : entry.getLatency();
    }

    private static void samplePing(MinecraftClient mc) {
        int value = ping(mc);
        // Spike = clearly higher than the recent average and high in absolute terms.
        if (pingCount >= 10 && value > 150 && value > averagePing() * 2) {
            spikeUntil = System.currentTimeMillis() + 3000;
        }
        PINGS[pingHead] = value;
        pingHead = (pingHead + 1) % HISTORY;
        if (pingCount < HISTORY) pingCount++;
    }

    public static int pingCount() {
        return pingCount;
    }

    /** i = 0 is the oldest stored sample. */
    public static int pingAt(int i) {
        int start = (pingHead - pingCount + HISTORY) % HISTORY;
        return PINGS[(start + i) % HISTORY];
    }

    public static int averagePing() {
        if (pingCount == 0) return 0;
        long sum = 0;
        for (int i = 0; i < pingCount; i++) sum += pingAt(i);
        return (int) (sum / pingCount);
    }

    public static int maxPing() {
        int max = 0;
        for (int i = 0; i < pingCount; i++) max = Math.max(max, pingAt(i));
        return max;
    }
}
