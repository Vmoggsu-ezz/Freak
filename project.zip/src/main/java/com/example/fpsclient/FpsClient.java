package com.example.fpsclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class FpsClient implements ClientModInitializer {
    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("fpsclient", "main"));

    static KeyBinding menuKey;
    private KeyBinding boosterKey;
    private KeyBinding zoomKey;

    private boolean zooming;
    private int savedFov;
    private double savedSensitivity;
    private boolean sprintHeldByUs;

    @Override
    public void onInitializeClient() {
        Feature.loadAll();
        AnchorPrediction.register();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fpsclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        boosterKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fpsclient.booster", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, CATEGORY));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fpsclient.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));

        HudRenderCallback.EVENT.register(Hud::render);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        ClientLifecycleEvents.CLIENT_STARTED.register(mc -> Feature.applyOnStart());
        // Put your normal video settings back so the options file is never left "boosted".
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
            stopZoom(mc);
            FpsBooster.apply(false);
            SteadyView.apply(false);
            LowLatency.apply(false);
            mc.options.write();
        });
    }

    private void tick(MinecraftClient mc) {
        while (menuKey.wasPressed()) {
            if (mc.currentScreen instanceof ModulesScreen) {
                mc.setScreen(null);
            } else if (mc.currentScreen == null) {
                mc.setScreen(new ModulesScreen());
            }
        }

        while (boosterKey.wasPressed() && mc.currentScreen == null) {
            Feature.BOOSTER.setEnabled(!Feature.BOOSTER.enabled());
            if (mc.player != null) {
                mc.player.sendMessage(
                        Text.literal("FPS Booster: " + (Feature.BOOSTER.enabled() ? "ON" : "OFF")), true);
            }
        }

        Stats.tick(mc);
        if (mc.player == null) return;

        // Toggle sprint: hold forward and you sprint, no key needed.
        if (Feature.TOGGLE_SPRINT.enabled() && mc.currentScreen == null) {
            if (mc.options.forwardKey.isPressed() && !mc.player.isSneaking()) {
                mc.options.sprintKey.setPressed(true);
                sprintHeldByUs = true;
            } else if (sprintHeldByUs) {
                mc.options.sprintKey.setPressed(false);
                sprintHeldByUs = false;
            }
        } else if (sprintHeldByUs) {
            mc.options.sprintKey.setPressed(false);
            sprintHeldByUs = false;
        }

        // Zoom: hold the zoom key (default C).
        boolean wantZoom = Feature.ZOOM.enabled() && mc.currentScreen == null && zoomKey.isPressed();
        if (wantZoom && !zooming) {
            savedFov = mc.options.getFov().getValue();
            savedSensitivity = mc.options.getMouseSensitivity().getValue();
            mc.options.getFov().setValue(30);
            mc.options.getMouseSensitivity().setValue(savedSensitivity * 0.4);
            zooming = true;
        } else if (!wantZoom && zooming) {
            stopZoom(mc);
        }
    }

    private void stopZoom(MinecraftClient mc) {
        if (!zooming) return;
        mc.options.getFov().setValue(savedFov);
        mc.options.getMouseSensitivity().setValue(savedSensitivity);
        zooming = false;
    }
}
