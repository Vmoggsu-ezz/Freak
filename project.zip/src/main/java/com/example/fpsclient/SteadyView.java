package com.example.fpsclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;

/**
 * Keeps the picture steady: no view bobbing, no hurt-camera tilt, no FOV change
 * from sprinting or speed effects. Your previous values are restored when turned off.
 */
public final class SteadyView {
    private static boolean active;
    private static boolean bob;
    private static double tilt;
    private static double fovEffects;

    private SteadyView() {}

    public static void apply(boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;
        GameOptions o = mc.options;

        if (on && !active) {
            bob = o.getBobView().getValue();
            tilt = o.getDamageTiltStrength().getValue();
            fovEffects = o.getFovEffectScale().getValue();
            o.getBobView().setValue(false);
            o.getDamageTiltStrength().setValue(0.0);
            o.getFovEffectScale().setValue(0.0);
            active = true;
        } else if (!on && active) {
            o.getBobView().setValue(bob);
            o.getDamageTiltStrength().setValue(tilt);
            o.getFovEffectScale().setValue(fovEffects);
            active = false;
        }
    }
}
