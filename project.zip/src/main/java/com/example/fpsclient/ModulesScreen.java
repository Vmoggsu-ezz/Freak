package com.example.fpsclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

/** Menu with one toggle button per feature, in two columns (open with Right Shift). */
public class ModulesScreen extends Screen {

    public ModulesScreen() {
        super(Text.literal("FPS Client"));
    }

    @Override
    protected void init() {
        Feature[] all = Feature.values();
        int cols = 2;
        int rows = (all.length + cols - 1) / cols;
        int w = 150;
        int h = 20;
        int gap = 6;
        int step = 24;
        int x0 = width / 2 - (cols * w + (cols - 1) * gap) / 2;
        int y0 = height / 2 - (rows * step) / 2 + 10;

        for (int i = 0; i < all.length; i++) {
            Feature f = all[i];
            int col = i / rows;
            int row = i % rows;
            addDrawableChild(ButtonWidget.builder(label(f), btn -> {
                f.setEnabled(!f.enabled());
                btn.setMessage(label(f));
            }).dimensions(x0 + col * (w + gap), y0 + row * step, w, h).build());
        }
    }

    private static Text label(Feature f) {
        return Text.literal(f.label + ": " + (f.enabled() ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "FPS Client", width / 2, 20, 0xFFFFFFFF);
    }

    /** Vanilla does not run key bindings while a screen is open, so close on the menu key here. */
    @Override
    public boolean keyPressed(KeyInput input) {
        if (FpsClient.menuKey != null
                && input.key() == InputUtil.fromTranslationKey(FpsClient.menuKey.getBoundKeyTranslationKey()).getCode()) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
