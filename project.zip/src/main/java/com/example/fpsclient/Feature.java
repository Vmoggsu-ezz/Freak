package com.example.fpsclient;

import net.minecraft.client.MinecraftClient;

/** Every toggleable feature of the client. */
public enum Feature {
    FPS("FPS counter", true),
    CPS("CPS counter", true),
    PING("Ping", false),
    PING_GRAPH("Ping graph", false),
    SPEED("Speed (b/s)", false),
    CLOCK("Clock + day", false),
    MEMORY("Memory usage", false),
    COORDS("Coordinates", false),
    DIRECTION("Direction", false),
    DEATH_POINT("Last death point", false),
    ITEMS("Item counter", false),
    KEYSTROKES("Keystrokes", true),
    ARMOR("Armor status", true),
    POTIONS("Potion effects", true),
    TOGGLE_SPRINT("Toggle sprint", false),
    TOGGLE_SNEAK("Toggle sneak", false),
    STEADY_VIEW("Steady view", false),
    ANCHOR_PREDICT("Anchor prediction", false),
    LOW_LATENCY("Low latency mode", false),
    ZOOM("Zoom (hold C)", true),
    BOOSTER("FPS Booster", false);

    public final String label;
    private final boolean defaultOn;
    private boolean on;

    Feature(String label, boolean defaultOn) {
        this.label = label;
        this.defaultOn = defaultOn;
        this.on = defaultOn;
    }

    public boolean enabled() {
        return on;
    }

    public void setEnabled(boolean value) {
        if (on == value) return;
        on = value;
        Config.set(key(), value);
        switch (this) {
            case BOOSTER -> FpsBooster.apply(value);
            case STEADY_VIEW -> SteadyView.apply(value);
            case LOW_LATENCY -> LowLatency.apply(value);
            case TOGGLE_SNEAK -> setSneakToggle(value);
            default -> { }
        }
    }

    private String key() {
        return name().toLowerCase();
    }

    public static void loadAll() {
        Config.load();
        for (Feature f : values()) f.on = Config.get(f.key(), f.defaultOn);
    }

    /** Re-apply features that change game options (called once the game has finished starting). */
    public static void applyOnStart() {
        if (BOOSTER.on) FpsBooster.apply(true);
        if (STEADY_VIEW.on) SteadyView.apply(true);
        if (LOW_LATENCY.on) LowLatency.apply(true);
        if (TOGGLE_SNEAK.on) setSneakToggle(true);
    }

    private static void setSneakToggle(boolean value) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.options != null) mc.options.getSneakToggled().setValue(value);
    }
}
