@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle 9.2 or newer was not found on PATH.
  echo Install Gradle 9.2+ and Java 21, then run this file again.
  pause
  exit /b 1
)
gradle build
if errorlevel 1 exit /b 1
echo.
echo Built mod: build\libspsclient-fixed-1.21.11-1.0.1.jar
pause
