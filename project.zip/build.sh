#!/usr/bin/env sh
set -eu
gradle build
printf '\nBuilt mod: build/libs/fpsclient-fixed-1.21.11-1.0.1.jar\n'
